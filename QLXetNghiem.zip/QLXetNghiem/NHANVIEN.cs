namespace QLXetNghiem_TenBan
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("NHANVIEN")]
    public partial class NHANVIEN
    {
        [StringLength(12)]
        public string ID { get; set; }

        [Required]
        [StringLength(100)]
        public string HoTen { get; set; }

        public int? SoLanXN { get; set; }

        public bool? AmTinh { get; set; }

        [StringLength(10)]
        public string MaCty { get; set; }

        public virtual CONGTY CONGTY { get; set; }
    }
}
