﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace QLXetNghiem_TenBan
{
    public partial class Form1 : Form
    {
        Model1 db = new Model1();
        public Form1()
        {
            InitializeComponent();
        }

        private void cboCongTy_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            try
            {
                LoadComboBoxCongTy(); 
                LoadDanhSachNhanVien(); 
                KhoaMoGiaoDien(false); 
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi load dữ liệu: " + ex.Message);
            }
        }
        void LoadComboBoxCongTy()
        {
            // Lấy  danh sách công ty trong CSDL
            cboCongTy.DataSource = db.CONGTY.ToList();
            cboCongTy.DisplayMember = "TenCty"; //  hiện lên cho người dùng thấy
            cboCongTy.ValueMember = "MaCty";    //  giá trị ẩn bên dưới (để lưu vào CSDL)
        }

        void LoadDanhSachNhanVien()
        {
            // Dùng LINQ để lấy dữ liệu và hiển thị đẹp hơn
            var list = from nv in db.NHANVIEN
                       select new
                       {
                           ID = nv.ID,              
                           HoTen = nv.HoTen,        
                           SoLanXN = nv.SoLanXN,    

                           // Cột 4: Xử lý hiển thị chữ thay vì True/False
                           KetQua = nv.AmTinh == true ? "Âm tính" : "Dương tính",

                           // Cột 5: Lấy tên công ty từ bảng CONGTY (thông qua quan hệ)
                           TenCongTy = nv.CONGTY.TenCty
                       };

            dgvNhanVien.DataSource = list.ToList();
        }

        void KhoaMoGiaoDien(bool choPhep)
        {
            txtHoTen.Enabled = choPhep;
            cboCongTy.Enabled = choPhep;
            radAmTinh.Enabled = choPhep;
            radDuongTinh.Enabled = choPhep;

            // Nút Cập Nhật chỉ sáng lên khi đang ở chế độ cho phép nhập
            btnCapNhat.Enabled = choPhep;

            // Ô số lần XN luôn luôn khóa (vì tự động tăng)
            txtSLXN.Enabled = false;
        }


        private void btnTim_Click(object sender, EventArgs e)
        {
            string idCanTim = txtID.Text.Trim();

            // Validate: Kiểm tra xem đã nhập ID chưa
            if (string.IsNullOrEmpty(idCanTim))
            {
                MessageBox.Show("Vui lòng nhập CCCD/CMND cần tìm!");
                return;
            }

            // Tìm trong kho dữ liệu xem có nhân viên này chưa
            var nv = db.NHANVIEN.Find(idCanTim);

            if (nv != null) // TRƯỜNG HỢP 1: TÌM THẤY (Đã có trong CSDL)
            {
                // Đổ dữ liệu cũ lên giao diện
                txtHoTen.Text = nv.HoTen;
                cboCongTy.SelectedValue = nv.MaCty;

                // Logic: Số lần xét nghiệm mới = Số lần cũ + 1
                txtSLXN.Text = (nv.SoLanXN + 1).ToString();

                // Set kết quả cũ
                if (nv.AmTinh == true) radAmTinh.Checked = true;
                else radDuongTinh.Checked = true;

                // Mở khóa để cho phép sửa thông tin
                KhoaMoGiaoDien(true);
            }
            else // TRƯỜNG HỢP 2: KHÔNG TÌM THẤY (Nhân viên mới)
            {
                MessageBox.Show("Nhân viên chưa tồn tại. Vui lòng nhập thông tin mới!");

                // Xóa trắng các ô để nhập mới
                txtHoTen.Clear();
                txtSLXN.Text = "1"; // Mặc định lần đầu là 1
                radAmTinh.Checked = true; // Mặc định là Âm tính
                if (cboCongTy.Items.Count > 0) cboCongTy.SelectedIndex = 0;

                // Mở khóa để nhập
                KhoaMoGiaoDien(true);
                txtHoTen.Focus(); // Đưa con trỏ chuột vào ô Họ tên
            }
        }

        private void btnCapNhat_Click(object sender, EventArgs e)
        {
            try
            {
                // Kiểm tra dữ liệu đầu vào
                if (string.IsNullOrWhiteSpace(txtHoTen.Text))
                {
                    MessageBox.Show("Vui lòng nhập họ tên!");
                    return;
                }

                string id = txtID.Text;
                // Tìm lại lần nữa để xác định là Thêm hay Sửa
                var nv = db.NHANVIEN.Find(id);

                if (nv == null) 
                {
                    NHANVIEN nvMoi = new NHANVIEN();
                    nvMoi.ID = txtID.Text;
                    nvMoi.HoTen = txtHoTen.Text;
                    nvMoi.SoLanXN = int.Parse(txtSLXN.Text);
                    nvMoi.AmTinh = radAmTinh.Checked; 
                    nvMoi.MaCty = cboCongTy.SelectedValue.ToString();

                    db.NHANVIEN.Add(nvMoi); 
                    db.SaveChanges();        
                    MessageBox.Show("Thêm mới thành công!");
                }
                else 
                {
                    nv.HoTen = txtHoTen.Text;
                    nv.SoLanXN = int.Parse(txtSLXN.Text);
                    nv.AmTinh = radAmTinh.Checked;
                    nv.MaCty = cboCongTy.SelectedValue.ToString();

                    db.SaveChanges(); // Entity Framework tự biết dòng này đã sửa và lưu lại
                    MessageBox.Show("Cập nhật thành công!");
                }

                // Sau khi lưu xong thì tải lại bảng và reset form
                LoadDanhSachNhanVien();
                KhoaMoGiaoDien(false);
                txtID.Clear();
                txtHoTen.Clear();
                txtSLXN.Clear();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi khi cập nhật: " + ex.Message);
            }
        }

        private void danhSáchNVDươngTínhToolStripMenuItem_Click(object sender, EventArgs e)
        {
            var list = db.NHANVIEN.Where(x => x.AmTinh == false)
                         .Select(x => new {
                             ID = x.ID,
                             HoTen = x.HoTen,
                             SoLanXN = x.SoLanXN,
                             KetQua = "Dương tính",
                             TenCongTy = x.CONGTY.TenCty
                         }).ToList();

            dgvNhanVien.DataSource = list;
            MessageBox.Show($"Tìm thấy {list.Count} nhân viên dương tính.", "Thông báo");
        }

        private void danhSáchCtyĐãTestTheoYCToolStripMenuItem_Click(object sender, EventArgs e)
        {
            // Logic: Đếm số nhân viên của từng công ty, so sánh với chỉ tiêu SLNV
            var list = db.CONGTY.Where(cty => cty.NHANVIEN.Count >= cty.SLNV)
                       .Select(cty => new
                       {
                           TenCongTy = cty.TenCty,
                           ChiTieu = cty.SLNV,
                           DaTest = cty.NHANVIEN.Count,
                           TrangThai = "Đạt yêu cầu"
                       }).ToList();

            dgvNhanVien.DataSource = list;

            // Hiện thông báo dạng danh sách (như đề bài yêu cầu hình 2)
            string thongBao = "Các công ty đã test đủ Y/C:\n";
            foreach (var item in list)
            {
                thongBao += $"- {item.TenCongTy}\n";
            }
            MessageBox.Show(thongBao, "Kết quả");
        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void txtHoTen_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
